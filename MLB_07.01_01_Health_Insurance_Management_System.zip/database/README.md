### Make a new Database (`hims_db`) in your MySQL-DBMS (`phpMyAdmin`).
### Import tables from `project/database` directory.


```
> make new database by project db-name.
>
> > http://localhost/phpmyadmin/

> import tables.sql files to your created database.
>
> > http://localhost/phpmyadmin/index.php?route=/database/import&db=hims_db
```


    After choose the tables.sql files from directory.
    (ex: `C:\xampp\htdocs\hims-iwt-final-project\database`)

    Then unchecked this tic ->>

    Other options:
        [] `Enable foreign key checks`
    Format:
        SQL

    Then Click ->> `Go`

