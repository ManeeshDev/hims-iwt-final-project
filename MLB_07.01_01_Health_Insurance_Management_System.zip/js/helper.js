
export const numRound = (value = '0') => {
    return Math.round(Number(value));
}
